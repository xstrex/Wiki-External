<?php

$lang['btn_dw_edit'] = "Modifica DW";
$lang['dw_btn_fck_preview']= "Anteprima CKG";
$lang['dw_btn_lang']= "Lingua";
$lang['title_dw_delete'] = "Elimina pagina";
$lang['title_dw_edit'] = "Salva, Esci e passa all'editor nativo di DokuWiki";
$lang['dw_btn_revert'] = "Ripristina";
$lang['title_dw_revert'] = "Ripristina il backup precedente";
$lang['title_dw_lang']= "Seleziona lingua per controllo ortografico";
$lang['title_dw_cancel']= "Uscita editor";
$lang['btn_fck_edit'] = "Modifica CKG";
$lang['confirm_delete'] = "Sei sicuro di voler eliminare questa pagina?";
$lang['confirm_preview'] = "I dati non salvati andranno persi.";

$lang['dw_btn_backup'] = "Backup";
$lang['title_dw_backup'] ="Finestra backup editor & Rinnovo blocco";
$lang['backup_empty'] = "Il buffer di backup sembra essere vuoto. Vuoi continuare?";
$lang['btn_draft'] = "Visualizza bozza";
$lang['title_draft'] = "Visualizza, Mostra, Modifica bozza";
$lang['btn_exit_draft'] = "Uscita bozza";
$lang['title_draft'] = "Visualizza, Mostra, Modifica bozza";
$lang['title_exit_draft'] = "Torna al documento attuale";
$lang['draft_msg']= "Questo documento contiene un file bozza. Il tasto bozza permette di passare da questo documento alla bozza. Puoi modificare e salvare uno dei due documenti.";