<?php
//global $lang;

$lang['btn_dw_edit'] = "المحرر النصي";
$lang['dw_btn_fck_preview']="معاينة CKG";
$lang['dw_btn_lang']="اللغة";
$lang['title_dw_delete'] = "احذف الصفحة";
$lang['title_dw_edit'] = "احفظ العمل، أخرج، وحول إلى المحرر النصي الافتراضي";
$lang['dw_btn_revert'] = "تراجع";
$lang['title_dw_revert'] = "تراجع للنسخ الاحتياطي السابق";
$lang['title_dw_lang']="اختر لغة للمددق الإملائي";
$lang['title_dw_cancel']='اخرج من المحرر';
$lang['btn_fck_edit'] = "المحرر الرسومي";
$lang['confirm_delete'] = "أمتأكد من رغبتك بحذف هذه الصفحة؟";
$lang['confirm_preview'] = "ستخسر كل مالم تحفظه.";
$lang['dw_btn_backup'] ="انسخ احتياطيا";
$lang['title_dw_backup'] ="انسخ محتوى المحرر احتياطيا ونشط قفل الصفحة";
$lang['backup_empty'] = "محفوظات النسخ الاحتياطي فارغة. هل تريد الإستمرار?";
$lang['btn_draft'] = "اجلب المسودة";
$lang['title_draft'] = "اعرض, أظهر, حرر المسودة";
$lang['btn_exit_draft'] = "اخرج من المسودة";
$lang['title_draft'] = "اعرض, أظهر, حرر المسودة";
$lang['title_exit_draft'] = "ارجع للمستند الحالي";
$lang['draft_msg']= "هناك مسودة لهذا المستند. زر المسودة يبدل بين هذا المستند والمسودة. يمكنك حفظ وتحرير أيا منهما." ;


