<?php

$lang['btn_dw_edit'] = "Editor de Código";
$lang['dw_btn_fck_preview']="Exibição do Editor Visual";
$lang['dw_btn_lang']="Idioma";
$lang['title_dw_delete'] = "Excluir a Página";
$lang['title_dw_edit'] = "Salvar o trabalho, sair e trocar para o Editor de Código nativo do DokuWiki";
$lang['dw_btn_revert'] = "Reverter";
$lang['title_dw_revert'] = "Reverter para o backup anterior";
$lang['title_dw_lang']="Selecionar o idioma para o verificador de ortografia";
$lang['title_dw_cancel']='Sair do Editor';
$lang['btn_fck_edit'] = "Editor Visual";
$lang['confirm_delete'] = "Tem certeza de querer excluir esta página?";
$lang['confirm_preview'] = "Qualquer trabalho não salvo será perdido.";

$lang['dw_btn_backup'] ="Back-up";
$lang['title_dw_backup'] ="Tela de edição do back up e bloqueio de recuperação";
$lang['backup_empty'] = "O registro de back-up parece estar vazio. Quer continuar?";
$lang['btn_draft'] = "Obter Rascunho";
$lang['title_draft'] = "Ver, Mostrar, Editar o Rascunho";
$lang['btn_exit_draft'] = "Sair do Rascunho";
$lang['title_draft'] = "Ver, Mostrar, Editar o Rascunho";
$lang['title_exit_draft'] = "Returnar ao documento atual";
$lang['draft_msg']= "Este documento tem um arquivo de rascunho. O botão Rascunho troca entre este documento e o rascunho. Você pode editar e salvar qualquer um dos dois." ;

