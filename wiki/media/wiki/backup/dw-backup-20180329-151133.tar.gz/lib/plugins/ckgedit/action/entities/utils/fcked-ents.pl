use strict;



while(<DATA>) {
 chomp;
 my($icon, $num, $character) = split;
 next if !$icon || !$num || ! $character;
# $icon = trim($icon);
# $num = trim($num);
# $character=trim($character);
 print "$icon\n$num\n$character\n\n";
}

sub trim {
 my $str = shift;
 $str =~ s/^\s+//;
 $str =~ s/\s+$//;
 return $str;
}

__DATA__
  nbsp 160   
¡ iexcl 161   
¢ cent 162   
£ pound 163   
¤ curren 164   
¥ yen 165   
¦ brvbar 166   
§ sect 167   
¨ uml 168   
© copy 169   
ª ordf 170   
« laquo 171   
¬ not 172   
­ shy 173   
® reg 174   
¯ macr 175   
° deg 176   
± plusmn 177   
² sup2 178   
³ sup3 179   
´ acute 180   
µ micro 181   
¶ para 182   
· middot 183   
¸ cedil 184   
¹ sup1 185   
º ordm 186   
» raquo 187   
¼ frac14 188   
½ frac12 189   
¾ frac34 190   
¿ iquest 191   
à agrave 192   
á aacute 193   
â acirc 194   
ã atilde 195   
Ä Auml 196   
å aring 197   
æ aelig 198   
ç ccedil 199   
è egrave 200   
é eacute 201   
ê ecirc 202   
ë euml 203   
ì igrave 204   
í iacute 205   
î icirc 206   
ï iuml 207   
ð eth 208   
ñ ntilde 209   
ò ograve 210   
ó oacute 211   
ô ocirc 212   
õ otilde 213   
Ö Ouml 214   
× times 215   
ø oslash 216   
ù ugrave 217   
ú uacute 218   
û ucirc 219   
Ü Uuml 220   
ý yacute 221   
þ thorn 222   
ß szlig 223   
à agrave 224   
á aacute 225   
â acirc 226   
ã atilde 227   
ä auml 228   
å aring 229   
æ aelig 230   
ç ccedil 231   
è egrave 232   
é eacute 233   
ê ecirc 234   
ë euml 235   
ì igrave 236   
í iacute 237   
î icirc 238   
ï iuml 239   
ð eth 240   
ñ ntilde 241   
ò ograve 242   
ó oacute 243   
ô ocirc 244   
õ otilde 245   
ö ouml 246   
÷ divide 247   
ø oslash 248   
ù ugrave 249   
ú uacute 250   
û ucirc 251   
ü uuml 252   
ý yacute 253   
þ thorn 254   
ÿ yuml 255   
" quot 34   
& amp 38   
< lt 60   
> gt 62   
œ oelig 338   
œ oelig 339   
š scaron 352   
š scaron 353   
ÿ yuml 376   
ˆ circ 710   
˜ tilde 732   
  ensp 8194   
  emsp 8195   
  thinsp 8201    
– ndash 8211   
— mdash 8212   
‘ lsquo 8216   
’ rsquo 8217   
‚ sbquo 8218   
“ ldquo 8220   
” rdquo 8221   
„ bdquo 8222   
† dagger 8224   
† dagger 8225   
‰ permil 8240   
‹ lsaquo 8249   
› rsaquo 8250   
€ euro 8364   
ƒ fnof 402   
α alpha 913   
β beta 914   
γ gamma 915   
δ delta 916   
ε epsilon 917   
ζ zeta 918   
η eta 919   
θ theta 920   
ι iota 921   
κ kappa 922   
λ lambda 923   
μ mu 924   
ν nu 925   
ξ xi 926   
ο omicron 927   
π pi 928   
ρ rho 929   
σ sigma 931   
τ tau 932   
υ upsilon 933   
φ phi 934   
χ chi 935   
ψ psi 936   
ω omega 937   
α alpha 945   
β beta 946   
γ gamma 947   
δ delta 948   
ε epsilon 949   
ζ zeta 950   
η eta 951   
θ theta 952   
ι iota 953   
κ kappa 954   
λ lambda 955   
μ mu 956   
ν nu 957   
ξ xi 958   
ο omicron 959   
π pi 960   
ρ rho 961   
ς sigmaf 962   
σ sigma 963   
τ tau 964   
υ upsilon 965   
φ phi 966   
χ chi 967   
ψ psi 968   
ω omega 969    
• bull 8226   
… hellip 8230   
′ prime 8242   
′ prime 8243   
‾ oline 8254   
⁄ frasl 8260 
← larr 8592   
↑ uarr 8593   
→ rarr 8594   
↓ darr 8595   
↔ harr 8596   
← larr 8656   
↑ uarr 8657   
→ rarr 8658   
↓ darr 8659   
↔ harr 8660      
∂ part 8706      
∏ prod 8719   
∑ sum 8721   
− minus 8722   
√ radic 8730   
∞ infin 8734     
∩ cap 8745      
∫ int 8747      
≈ asymp 8776   
≠ ne 8800   
≡ equiv 8801   
≤ le 8804   
≥ ge 8805      
◊ loz 9674   
♠ spades 9824   
♣ clubs 9827   
♥ hearts 9829   
♦ diams 9830   

