<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author pochin <qwe852147@hotmail.com>
 */
$lang['btn_dw_edit']           = 'DW編輯';
$lang['dw_btn_fck_preview']    = 'CKG預覽';
$lang['dw_btn_lang']           = '語言';
$lang['title_dw_delete']       = '刪除頁面';
$lang['title_dw_edit']         = '存檔離開後切換到預設編輯器';
$lang['dw_btn_revert']         = '還原';
$lang['title_dw_revert']       = '還原備份檔';
$lang['title_dw_lang']         = '選擇拼字檢查的語言';
$lang['title_dw_cancel']       = '離開編輯器';
$lang['btn_fck_edit']          = 'CKG編輯';
$lang['confirm_delete']        = '確定要刪除頁面嗎?';
$lang['confirm_preview']       = '你將會遺失尚未儲存的資料';
$lang['editor_height']         = '編輯器高度';
$lang['editor_height_title']   = '編輯器於頁面刷新時，重新調整大小';
$lang['dw_btn_backup']         = '備份';
$lang['title_dw_backup']       = '備份現在的資料並更新鎖定定時器';
$lang['backup_empty']          = '備份暫存區沒有資料可提供還原，仍要繼續嗎?';
$lang['btn_draft']             = '載入草稿';
$lang['title_draft']           = '檢視並編輯草稿';
$lang['btn_exit_draft']        = '編輯草稿';
$lang['title_exit_draft']      = '返回現行的檔案';
$lang['draft_msg']             = '有份編輯一半的草稿。請用下方的草稿鈕繼續編輯或移除';
$lang['whats_this']            = '這是什麼?';
$lang['complex_tables']        = '使用複雜性表格';
$lang['minor_changes']         = '微小修訂';
$lang['discard_edits']         = '按 OK 以儲存你的修改，按 Cancel 放棄你的修改';
$lang['dw_btn_styling']        = '字形';
