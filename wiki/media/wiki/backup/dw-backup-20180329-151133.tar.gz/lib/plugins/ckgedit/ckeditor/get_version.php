<?php
/**
 lib/plugins/ckgedit/fckeditor/dwsmileys.php
*/



echo file_get_contents('../version');
