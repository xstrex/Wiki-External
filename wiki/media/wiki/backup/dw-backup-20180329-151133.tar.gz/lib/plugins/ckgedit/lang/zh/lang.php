<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author chenb <chenb84@foxmail.com>
 * @author 2576562185 <2576562185@qq.com>
 */
$lang['btn_dw_edit']           = 'DW脚本编辑';
$lang['dw_btn_fck_preview']    = 'CKG预览';
$lang['dw_btn_lang']           = '语言';
$lang['title_dw_delete']       = '删除页面';
$lang['title_dw_edit']         = '保存后退出，并切换到原生DokuWiki编辑器';
$lang['dw_btn_revert']         = '回滚';
$lang['title_dw_revert']       = '回滚到上次备份';
$lang['title_dw_lang']         = '选择拼写检查的语言';
$lang['title_dw_cancel']       = '退出编辑器';
$lang['btn_fck_edit']          = 'CKG可视编辑';
$lang['confirm_delete']        = '你确定要删除这个页面吗？';
$lang['confirm_preview']       = '没有存储的改动将会丢失。';
$lang['whats_this']            = '这是什么？';
