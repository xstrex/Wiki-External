ckgedit is a WYSIWYG editor for Dokuwiki.  It is an implementation of fckgLite which replaces the
FCKEditor with the more current CKEditor. Whereas the base directory for fckgLite is named fckg, the 
base directory for this version is ckgedit. However, only one of the two can
be enabled at any one time.  

This version of ckgeditor should work with Linux, Windows, and versions of Dokuwiki installed with the 
Ubuntu/Debian package manager.

This branch uses CKEditor 4.7




