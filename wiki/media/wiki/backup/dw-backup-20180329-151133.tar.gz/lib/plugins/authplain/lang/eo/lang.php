<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Pardonu, ĉi tiu uzanto-nomo jam ekzistas.';
