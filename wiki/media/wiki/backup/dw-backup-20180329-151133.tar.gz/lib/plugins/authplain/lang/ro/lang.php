<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']            = 'Ne pare rău, un utilizator cu acest nume este deja autentificat.';
