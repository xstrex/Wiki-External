<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Domingo Redal <docxml@gmail.com>
 * @author Enny Rodriguez <aquilez.4@gmail.com>
 */
$lang['userexists']            = 'Lo siento, ya existe un usuario con este nombre.';
$lang['usernotexists']         = 'Lo sentimos, no existe ese usuario.';
$lang['writefail']             = 'No es posible modificar los datos del usuario. Por favor, informa al Administrador del Wiki';
$lang['protected']             = 'Los datos del usuario % están protegidos y no pueden ser modificados o eliminados.';
