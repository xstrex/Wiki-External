<?php
/**
 * Macedonian language file
 *
 * @author Dimitar Talevski <dimi3.14@gmail.com>
 */
$lang['acl_group']             = 'Група:';
$lang['acl_user']              = 'Корисник:';
$lang['acl_perms']             = 'Пермисии за';
$lang['page']                  = 'Страница';
$lang['btn_select']            = 'Избери';
$lang['current']               = 'Моментални ACL правила';
$lang['who']                   = 'Корисник/група';
$lang['perm']                  = 'Пермисии';
$lang['acl_perm0']             = 'Ништо';
$lang['acl_perm1']             = 'Читај';
$lang['acl_perm2']             = 'Уреди';
$lang['acl_perm4']             = 'Креирај';
$lang['acl_perm8']             = 'Качи';
$lang['acl_perm16']            = 'Избриши';
$lang['acl_new']               = 'Додај нов запис';
$lang['acl_mod']               = 'Измени запис';
