<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Juliano Marconi Lanigra <juliano.marconi@gmail.com>
 */
$lang['testfailed']            = 'Desculpe, mas o CAPTCHA não foi preenchido corretamente. Talvez você não seja humano?';
$lang['fillcaptcha']           = 'Por favor preencha todas as letras dentro da caixa para provar que você é humano.';
$lang['fillmath']              = 'Por favor resolva a seguinte equação para provar que você é humano.';
$lang['soundlink']             = 'Se você não pode ler as letras na imagem, faça o download desse .wav para que elas sejam lidas para você.';
$lang['honeypot']              = 'Por favor deixe esse campo em branco:';
