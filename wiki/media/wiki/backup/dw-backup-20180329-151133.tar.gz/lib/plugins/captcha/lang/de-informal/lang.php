<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Thomas Templin <templin@gnuwhv.de>
 */
$lang['testfailed']            = 'Das CAPTCHA wurde nicht korrekt beantwortet.';
$lang['fillcaptcha']           = 'Bitte übertrage die Buchstaben in das Eingabefeld.';
$lang['fillmath']              = 'Bitte löse folgende Gleichung:';
$lang['soundlink']             = 'Wenn Du die Buchstaben auf dem Bild nicht lesen kannst, lade diese .wav Datei herunter, um sie vorgelesen zu bekommen.';
$lang['honeypot']              = 'Dieses Feld bitte leer lassen';
