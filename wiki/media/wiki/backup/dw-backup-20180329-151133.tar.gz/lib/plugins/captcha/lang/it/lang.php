<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Willy
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['testfailed']            = 'Spiacente, ma non hai risposto correttamente a CAPTCHA. Potresti non essere del tutto umano.';
$lang['fillcaptcha']           = 'Per favore inserisci le lettere nel box accanto per provare che sei una persona reale.';
$lang['fillmath']              = 'Per favore risolvi la seguente equazione per dimostrare che sei un essere umano.';
$lang['soundlink']             = 'Se non riesci a leggere le lettere nell\'immagine, scarica questo file .wav ed eseguilo, leggerà le lettere per te.';
$lang['honeypot']              = 'Per favore lascia questo campo vuoto:';
