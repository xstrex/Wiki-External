<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Emmanuel Dupin <seedfloyd@gmail.com>
 * @author bruno <bruno@ninesys.fr>
 * @author Fabrice Dejaigher <fabrice@chtiland.com>
 */
$lang['testfailed']            = 'Désolé, vous n\'avez pas répondu correctement au test anti-spam. Peut-être n\'êtes vous pas humain ?';
$lang['fillcaptcha']           = 'Merci de recopier le code ci-contre pour prouver que vous êtes humain :';
$lang['fillmath']              = 'S\'il vous plaît résolvez l\'équation suivante pour prouver que vous êtes humain.';
$lang['soundlink']             = 'Si vous ne pouvez pas lire le code, téléchargez ce fichier .wav pour l\'écouter.';
$lang['honeypot']              = 'Merci de laisser ce champ vide : ';
