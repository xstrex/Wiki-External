<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author André Neves <drakferion@gmail.com>
 */
$lang['testfailed']            = 'Infelizmente o CAPTCHA não foi respondido corretamente. Talvez você afinal não seja humano?';
$lang['fillcaptcha']           = 'Por favor preencha todas as letras na caixa para provar que é humano.';
$lang['fillmath']              = 'Por favor resolva a seguinte equação para provar que é humano.';
$lang['soundlink']             = 'Se não pode ler as letras na imagem, descarregue este ficheiro .wav para as ouvir.';
$lang['honeypot']              = 'Por favor mantenha este campo vazio:';
