<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Serenity87HUN <anikototh87@gmail.com>
 */
$lang['testfailed']            = 'Rosszul válaszoltál a CAPTCHA-ra. Lehet, hogy nem is ember vagy?';
$lang['fillcaptcha']           = 'Kérlek írd be az összes betűt a dobozba, hogy bebizonyítsd, ember vagy.';
$lang['fillmath']              = 'Kérlek oldd meg az alábbi egyenletet, hogy bebizonyítsd, ember vagy.';
$lang['soundlink']             = 'Ha nem látod a képen szereplő szöveget, töltsd le ezt a .wav fájlt, amiben felolvassák.';
$lang['honeypot']              = 'Ezt a mezőt kérlek hagyd üresen:';
