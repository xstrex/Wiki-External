<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author OHTSU Yoshifumi <dev@decomo.info>
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['testfailed']            = '申し訳ありませんが、CAPTCHAに対して適切に応答していません。おそらくですが人ではありませんね？';
$lang['fillcaptcha']           = '人間の証明として、ボックス内の全ての文字を入力してください。';
$lang['fillmath']              = '人間の証明として、以下の数式の答えを入力して下さい。';
$lang['soundlink']             = '画像の文字が読めなければ、文字を読んだ.wavファイルをダウンロードして下さい。';
$lang['honeypot']              = 'この項目は空のままにして下さい：';
