<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Oleksandr Baranyuk <boffin@drivehq.com>
 */
$lang['testfailed']            = 'Вибачте, ви дали неправильну CAPTCHA-відповідь. Може ви взагалі не людина?';
$lang['fillcaptcha']           = 'Будь ласка неберіть всі символи аби підтвердити, що ви людина.';
$lang['fillmath']              = 'Розв\'жіть, будь ласка це рівняння аби підтвердити, що ви людина.';
$lang['soundlink']             = 'Якщо ви не можете прочитати літери на картинці, завантажте цей .wav файл і прослухайте.';
$lang['honeypot']              = 'Залиште це поле порожнім:';
