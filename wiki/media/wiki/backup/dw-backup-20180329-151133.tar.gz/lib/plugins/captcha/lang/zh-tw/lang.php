<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Danny Lin <danny0838@pchome.com.tw>
 * @author lioujheyu <lioujheyu@gmail.com>
 */
$lang['testfailed']            = '很抱歉，您沒有輸入正確的 CAPTCHA 驗證碼。';
$lang['fillcaptcha']           = '請將字母填入方框。';
$lang['fillmath']              = '請解開下列方程式以證明你是人類';
$lang['soundlink']             = '如果您無法閱讀圖片中的字母，請下載收聽這個 WAV 檔。';
$lang['honeypot']              = '請保持這個欄位空白';
