<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alan Davies <ben.brynsadler@gmail.com>
 */
$lang['mode']                  = 'Pa fath CAPTCHA i\'w ddefnyddio?';
$lang['mode_o_js']             = 'Testun (wedi\'i rhaglenwi gan JavaScript)';
$lang['mode_o_text']           = 'Testun (gan law yn unig)';
$lang['mode_o_math']           = 'Problem fathemategol';
$lang['mode_o_question']       = 'Cwestiwn gosodedig';
$lang['mode_o_image']          = 'Delwedd (hygyrchedd gwael)';
$lang['mode_o_audio']          = 'Delwedd+Sain (gwell hygyrchedd)';
$lang['mode_o_figlet']         = 'Celf Figlet ASCII (hygyrchedd gwael)';
$lang['forusers']              = 'Defnyddio CAPTCHA ar gyfer defnyddwyr sydd wedi mewngofnodi hefyd?';
$lang['loginprotect']          = 'Angen CAPTCHA i fewngofnodi?';
$lang['lettercount']           = 'Bufer y llythrennau i\'w defnyddio (3-16). Os ydych chi\'n cynnyddu\'r nifer, sicrhewch eich bod chi\'n cynyddu lled y ddelwedd isod hefyd.';
$lang['width']                 = 'Lled y ddelwedd CAPTCHA (picsel)';
$lang['height']                = 'Uchder y ddelwedd CAPTCHA (picsel)';
$lang['question']              = 'Cwestiwn ar gyfer modd cwestiwn gosodedig';
$lang['answer']                = 'Ateb ar gyfer modd cwestiwn gosodedig';
