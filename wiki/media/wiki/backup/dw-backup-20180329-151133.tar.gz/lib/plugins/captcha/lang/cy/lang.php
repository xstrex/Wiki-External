<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alan Davies <ben.brynsadler@gmail.com>
 */
$lang['testfailed']            = 'Sori, ond wnaethoch chi ddim ateb y CAPTCHA\'n gywir. Efallai \'dych chi ddim yn ddynol wedi\'r cyfan?';
$lang['fillcaptcha']           = 'Llenwch pob llythyren i\'r blwch i brofi\'ch bod chi\'n ddynol.';
$lang['fillmath']              = 'Datryswch yr hafaliad canlynol i brofi\'ch bod chi\'n ddynol.';
$lang['soundlink']             = 'Os \'dych chi ddim yn gallu darllen llythrennau\'r ddelwedd, lawrlwythwch y ffeil .wav hwn er mwyn cael nhw wedi\'u darllen i chi.';
$lang['honeypot']              = 'Cadwch y maes hwn yn wag:';
