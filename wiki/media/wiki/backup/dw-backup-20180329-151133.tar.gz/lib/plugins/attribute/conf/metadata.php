<?php

/**
 * Options for the attribute plugin
 *
 * @author Mike Wilmes <mwilmes@avc.edu>
 */

$meta['store'] = array('string');
$meta['no_compress'] = array('onoff');
