<?php
$lang["store"] = 'Writeable direcotry to store attribute data into';
$lang["no_compress"] = 'Do not compress data to facilitate debugging.  LEAVES ALL DATA IN PLAINTEXT.  **LEAVE OFF**';
