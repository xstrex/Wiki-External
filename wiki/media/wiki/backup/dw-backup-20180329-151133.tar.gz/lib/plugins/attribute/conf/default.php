<?php

/**
 * Default settings for the attribute plugin
 * @author Mike Wilmes <mwilmes@avc.edu>
 */

$conf['store'] = 'data/attribute';
$conf['no_compress'] = 0;
