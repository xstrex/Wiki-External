# attribute
Arbitrary attribute definition and storage for user associated data.

See detail on: https://www.dokuwiki.org/plugin:attribute
