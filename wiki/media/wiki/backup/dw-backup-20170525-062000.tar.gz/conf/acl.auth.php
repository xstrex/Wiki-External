# acl.auth.php
# <?php exit()?>
*	@ALL	1
*	strex	16
