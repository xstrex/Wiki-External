<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author ilker rifat kapaç <irifat@gmail.com>
 */
$lang['bindpw']                = 'Üstteki kullanıcının şifresi';
