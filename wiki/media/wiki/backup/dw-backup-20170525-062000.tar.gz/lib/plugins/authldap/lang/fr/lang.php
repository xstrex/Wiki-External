<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Pietroni <pietroni@informatique.univ-paris-diderot.fr>
 */
$lang['connectfail']           = 'LDAP ne peux se connecter : %s';
$lang['domainfail']            = 'LDAP ne trouve pas l\'utilisateur dn';
