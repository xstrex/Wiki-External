<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Paulo Carmino <contato@paulocarmino.com>
 */
$lang['connectfail']           = 'Falha ao conectar com o banco de dados.';
$lang['userexists']            = 'Desculpe, esse login já está sendo usado.';
