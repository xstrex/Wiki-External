<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['connectfail']           = 'Ne mogu se spojiti na bazu.';
$lang['userexists']            = 'Oprostite ali korisnik s ovom prijavom već postoji.';
$lang['writefail']             = 'Ne mogu izmijeniti podatke. Molim obavijestite Wiki administratora';
