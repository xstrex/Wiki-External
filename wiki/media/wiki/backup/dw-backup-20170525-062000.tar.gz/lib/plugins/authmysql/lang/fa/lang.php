<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mohmmad Razavi <sepent@gmail.com>
 * @author Masoud Sadrnezhaad <masoud@sadrnezhaad.ir>
 */
$lang['connectfail']           = 'خطا در اتصال به دیتابیس';
$lang['userexists']            = 'با عرض پوزش، یک کاربر با این نام از قبل وجود دارد.';
$lang['usernotexists']         = 'با عرض پوزش، آن کاربر وجود نداشت.';
$lang['writefail']             = 'امکان تغییر داده کاربر وجود نداشت. لطفا مسئول Wiki را آگاه کنید.';
