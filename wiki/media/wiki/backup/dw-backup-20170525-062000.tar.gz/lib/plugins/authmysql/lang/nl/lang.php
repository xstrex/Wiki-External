<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hugo Smet <hugo.smet@scarlet.be>
 */
$lang['connectfail']           = 'Connectie met de database mislukt.';
$lang['userexists']            = 'Sorry, een gebruiker met deze login bestaat reeds.';
$lang['usernotexists']         = 'Sorry, deze gebruiker bestaat niet.';
$lang['writefail']             = 'Onmogelijk om de gebruikers data te wijzigen. Gelieve de Wiki-Admin te informeren.';
