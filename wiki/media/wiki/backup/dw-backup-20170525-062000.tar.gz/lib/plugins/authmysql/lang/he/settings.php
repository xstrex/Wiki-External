<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Menashe Tomer <menashesite@gmail.com>
 */
$lang['getUserID']             = 'שאילתת SQL לקבלת מפתח ראשי של המשתמש';
$lang['UpdateLogin']           = 'שאילתת SQL לעדכון שם המשתמש';
$lang['UpdatePass']            = 'שאילתת SQL לעדכון סיסמת המשתמש';
$lang['UpdateEmail']           = 'שאילתת SQL לעדכון כתובת הדוא"ל של המשתמש';
$lang['UpdateName']            = 'שאילתת SQL לעדכון שם המשתמש';
