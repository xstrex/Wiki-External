<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 */
$lang['userexists']            = '很抱歉，有人已使用了這個帳號。';
