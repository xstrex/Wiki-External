<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hugo Smet <hugo.smet@scarlet.be>
 */
$lang['userexists']            = 'Er bestaat al een gebruiker met deze loginnaam.';
$lang['usernotexists']         = 'Sorry, deze gebruiker bestaat niet.';
$lang['writefail']             = 'Onmogelijk om de gebruikers data te wijzigen. Gelieve de Wiki-Admin te informeren.';
