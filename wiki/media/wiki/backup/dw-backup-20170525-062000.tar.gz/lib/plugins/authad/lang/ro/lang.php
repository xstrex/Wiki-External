<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Razvan Deaconescu <razvan.deaconescu@cs.pub.ro>
 * @author Adrian Vesa <adrianvesa@dotwikis.com>
 */
$lang['authpwdexpire']         = 'Parola va expira în %d zile, ar trebui să o schimbi în curând.';
$lang['passchangefail']        = 'Parola nu a putu fi schimbata. Poate politica pentru parole nu a fost indeplinita ?';
$lang['userchangefail']        = 'Nu am putu schimba atributiile pentru acest utilizator. Poate nu ai permisiunea sa faci aceste schimbari ?';
