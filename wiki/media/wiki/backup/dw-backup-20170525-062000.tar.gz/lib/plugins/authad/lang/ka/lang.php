<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Luka Lejava <luka.lejava@gmail.com>
 */
$lang['authpwdexpire']         = 'თქვენს პაროლს ვადა გაუვა %d დღეში, მალე შეცვლა მოგიწევთ.';
