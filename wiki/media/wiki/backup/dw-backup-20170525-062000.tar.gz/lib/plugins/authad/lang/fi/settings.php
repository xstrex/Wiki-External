<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Otto Vainio <otto@valjakko.net>
 */
$lang['debug']                 = 'Näytä lisää debug-koodia virheistä?';
$lang['expirywarn']            = 'Montako päivää etukäteen varoitetaan salasanan vanhenemissta. 0 poistaa.';
