# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# user:MD5password:Real Name:email:groups,comma,seperated


strex:b90622e8cfcee9fb454ee942506efd98:Strex:strex@morphx.net:admin,user
