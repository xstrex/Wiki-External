<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['connectfail']           = 'Connessione fallita al database.';
$lang['userexists']            = 'Spiacente, esiste già un utente con queste credenziali.';
$lang['writefail']             = 'Non è possibile cambiare le informazioni utente. Si prega di informare l\'Amministratore del wiki';
