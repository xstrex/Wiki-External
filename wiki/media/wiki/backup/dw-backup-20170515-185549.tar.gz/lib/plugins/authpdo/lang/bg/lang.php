<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Kiril <neohidra@gmail.com>
 */
$lang['connectfail']           = 'Свързването с базата данни се провали.';
$lang['userexists']            = 'За съжаление вече съществува потребител с това име.';
