<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Takumo <9206984@mail.ru>
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['connectfail']           = 'Ошибка соединения с базой данных.';
$lang['userexists']            = 'Извините, пользователь с таким логином уже существует.';
$lang['writefail']             = 'Невозможно изменить данные пользователя. Сообщите об этом администратору вики.';
