<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jussi Takala <jussi.takala@live.fi>
 */
$lang['server']                = 'Sinun MySQL-serveri';
$lang['user']                  = 'MySQL-käyttäjänimi';
$lang['password']              = 'Salasana yläolevalle käyttäjälle';
$lang['charset']               = 'Käytetty merkistö tietokannassa';
