<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author alhajr <alhajr300@gmail.com>
 */
$lang['port']                  = 'LDAP المنفذ الملقم إذا لم يعط أي عنوان URL كامل أعلاه';
$lang['version']               = 'إصدار نسخة البروتوكول الستخدامه. قد تحتاج لتعيين هذه القيمة إلى <code>3</code>';
$lang['starttls']              = 'استخدام اتصالات TLS؟';
$lang['referrals']             = 'يتبع الإحالات؟';
$lang['deref']                 = 'كيفية إلغاء مرجعية الأسماء المستعارة؟';
$lang['bindpw']                = 'كلمة مرور المستخدم أعلاه';
