<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Philip Knack <p.knack@stollfuss.de>
 */
$lang['connectfail']           = 'LDAP-Verbindung scheitert: %s';
$lang['domainfail']            = 'LDAP kann nicht dein Benutzer finden dn';
