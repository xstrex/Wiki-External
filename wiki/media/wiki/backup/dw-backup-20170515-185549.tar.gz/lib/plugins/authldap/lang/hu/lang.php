<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Marton Sebok <sebokmarton@gmail.com>
 */
$lang['connectfail']           = 'Az LDAP nem tudott csatlakozni: %s';
$lang['domainfail']            = 'Az LDAP nem találta a felhasználód megkülönböztető nevét (DN)';
