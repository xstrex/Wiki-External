<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Paulo Carmino <contato@paulocarmino.com>
 */
$lang['connectfail']           = 'Não foi possível conectar o LDAP: %s';
$lang['domainfail']            = 'O LDAP não encontrou seu usuário';
