<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author RainbowSpike <1@2.ru>
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['userexists']            = 'Извините, пользователь с таким логином уже существует.';
$lang['usernotexists']         = 'Этот пользователь не зарегистрирован.';
$lang['writefail']             = 'Невозможно обновить данные пользователя. Свяжитесь с администратором вики';
