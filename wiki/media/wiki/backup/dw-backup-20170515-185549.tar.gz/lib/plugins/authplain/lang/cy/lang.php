<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Sori, mae defnyddiwr gyda\'r enw hwnnw eisoes yn bodoli.';
$lang['usernotexists']  = 'Sori, \'dyw\'r defnyddiwr hwnnw ddim yn bodoli.';
$lang['writefail']      = 'Methu â newid data defnyddiwr. Rhowch wybod i Weinydd y Wici';
