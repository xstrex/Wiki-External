<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['userexists']            = 'Il nome utente inserito esiste già.';
$lang['usernotexists']         = 'Spiacente, quell\'utente non esiste.';
$lang['writefail']             = 'Impossibile modificare i dati utente. Per favore informa l\'Amministratore del Wiki';
